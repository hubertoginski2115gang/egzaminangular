import { Component } from '@angular/core';
import { ComponentComponent } from "../component/component.component";

@Component({
    selector: 'app-component2',
    standalone: true,
    templateUrl: './component2.component.html',
    styleUrl: './component2.component.css',
    imports: [ComponentComponent]
})
export class Component2Component {

}
